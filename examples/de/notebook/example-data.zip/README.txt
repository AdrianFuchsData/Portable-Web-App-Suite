Temperaturen dreier Stationen (zufällige Beispieldaten).
