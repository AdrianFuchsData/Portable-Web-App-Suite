An archive with folders. Open files with a double click or “Open with…”.
