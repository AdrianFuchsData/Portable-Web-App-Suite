Temperatures of three stations (random example data).
